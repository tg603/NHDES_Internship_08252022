Simple single line of arrayValues.append(value_sum) changed to arrayValues.append(value_final). 
This allows for the correct value to now be appended to our csv data sheet.

This update's status is complete. 