This update involved putting the new version of mapMaking() into the Pull.py.
The new version contains the four last geojson's, html updates, and a finished for if procedure for putting the points within their respective regions.

This update's status is complete.