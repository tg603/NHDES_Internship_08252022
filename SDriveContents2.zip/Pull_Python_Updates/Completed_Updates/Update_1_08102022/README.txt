This update done and completed on 08/10/2022 made changes to the Pull.py as shown:

Inside of else if statement: elif(i =="PM2.5_JumpRelDiff"): *THIS OCCURS TWICE*
Underneath line of : value_sum = ((temporary_a + temporary_b) / 2)
Add new line of: value_final = round((abs(float(value_mean) / float(value_sum)) * 100),0)
Change line of: arrayValues.append(value_sum)
To line of: arrayValues.append(value_final)
*THE PROCEDURE ABOVE SHOULD BE DONE FOR BOTH OCCURANCES OF 'elif(i =="PM2.5_JumpRelDiff"):'*

Inside of else if statement: elif(i == "PM2.5_RelDiff"): *THIS OCCURS TWICE*
Change line of: value_final = round(value_final,0)
To line of: value_final = round(abs(value_final),0)
*THE PROCEDURE ABOVE SHOULD BE DONE FOR BOTH OCCURANCES OF 'elif(i == "PM2.5_RelDiff"):'*

The update also made two changes; those being the addition of os.removes for the NH.csv file which populates the map given in the nhPointMap.html and the removal of the unitjson's which were deemed to be scrap after viewing and retrieval.

The status of this update is complete.