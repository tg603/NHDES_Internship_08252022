'''

  Converts a given CSV to JSON.
  Reference for this was https://www.geeksforgeeks.org/convert-csv-to-json-using-python/
  
'''
def main():
    import csv
    import json
    import datetime

    baseName = "DESPurple08122022"

    csvFile = "{}.csv".format(baseName)
    jsonFile = "{}.json".format(baseName)
    data = {}

    # Date format for reading
    formatIn = "%m-%d-%Y %H:%M:%S"

    # Date format for writing (same as above but without seconds)
    formatOut = "%m-%d-%Y %H:%M"
    
    with open(csvFile, encoding="utf-8") as csvf:
        csvReader = csv.DictReader(csvf)

        for rows in csvReader:
            # Using "time_stamp" as the "key value"
            # But the actual "key" is like this:  "08-12-2022 00:01"
            rawKey = rows["time_stamp"]
            dt = datetime.datetime.strptime(rawKey, formatIn)
            key = dt.strftime(formatOut)
            if not key in data:
                data[key] = []
            data[key].append(rows)
            
    # Write to JSON.
    # Ideally, for web consumption, this would be gzipped.
    with open(jsonFile, "w", encoding="utf-8") as jsonf:
        jsonf.write(json.dumps(data, indent=4))

    print ("File {} has been prepared.".format(jsonFile))


if __name__ == '__main__':
  main()
